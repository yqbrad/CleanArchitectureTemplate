﻿using $safeprojectname$.Results;

namespace $safeprojectname$.Requests
{
    public interface IRequest { }

    public interface IRequest<TResult> { }
}