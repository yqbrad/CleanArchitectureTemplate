﻿namespace $safeprojectname$.Events
{
    public interface IDomainEvent
    {
    }
}