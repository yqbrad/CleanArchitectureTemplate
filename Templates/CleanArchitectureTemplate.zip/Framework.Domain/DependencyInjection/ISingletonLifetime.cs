﻿namespace $safeprojectname$.DependencyInjection
{
    public interface ISingletonLifetime { }

    public interface IScopeLifetime { }

    public interface ITransientLifetime { }
}