﻿namespace $safeprojectname$.Results
{
    public interface IResult
    {
    }
}