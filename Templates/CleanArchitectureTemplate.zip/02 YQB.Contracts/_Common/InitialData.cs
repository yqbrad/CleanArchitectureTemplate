﻿namespace $safeprojectname$._Common
{
    public class InitialData
    {
        public bool IsEnable { get; set; }
    }
}