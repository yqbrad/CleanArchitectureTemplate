﻿namespace $safeprojectname$._Base
{
    public class InitialData
    {
        public bool IsEnable { get; set; }
    }
}