﻿namespace $safeprojectname$.Sql
{
    public class SqlOptions
    {
        public string ConnectionString { get; set; }
    }
}