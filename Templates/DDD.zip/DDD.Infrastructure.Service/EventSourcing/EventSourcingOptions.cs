﻿namespace $safeprojectname$.EventSourcing
{
    public class EventSourcingOptions
    {
        public string ConnectionString { get; set; }
        public string ApplicationName { get; set; }
    }
}