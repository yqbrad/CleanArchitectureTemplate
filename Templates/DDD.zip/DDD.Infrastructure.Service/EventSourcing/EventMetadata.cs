﻿namespace $safeprojectname$.EventSourcing
{
    public class EventMetadata
    {
        public string ClrType { get; set; }
    }
}