﻿namespace $safeprojectname$.Redis
{
    public class RedisOptions
    {
        public string ConnectionString { get; set; }
    }
}