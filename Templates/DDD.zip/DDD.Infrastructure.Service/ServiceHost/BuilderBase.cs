﻿namespace $safeprojectname$.ServiceHost
{
    public abstract class IBuilderBase
    {
        public abstract ServiceHost Build();
    }
}