﻿namespace $safeprojectname$.ServiceHost
{
    public interface IServiceHost
    {
        void Run();
    }
}