﻿namespace $safeprojectname$.Events
{
    public interface IEvent
    {
    }
}