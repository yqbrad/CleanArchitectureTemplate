﻿namespace $safeprojectname$.Commands
{
    public interface ICommand
    {
    }
}