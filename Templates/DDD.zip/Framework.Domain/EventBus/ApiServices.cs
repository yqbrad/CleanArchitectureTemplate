﻿namespace $safeprojectname$.EventBus
{
    public class ApiServices
    {
        public ApiServices()
        {

        }
    }
}