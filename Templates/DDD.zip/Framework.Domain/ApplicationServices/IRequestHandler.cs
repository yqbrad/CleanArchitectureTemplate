﻿namespace $safeprojectname$.ApplicationServices
{
    public interface IRequestHandler
    {
    }
}