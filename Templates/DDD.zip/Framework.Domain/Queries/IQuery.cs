﻿namespace $safeprojectname$.Queries
{
    public interface IQuery
    {
    }
}