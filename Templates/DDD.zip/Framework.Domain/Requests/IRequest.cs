﻿namespace $safeprojectname$.Requests
{
    public interface IRequest
    {
    }
}