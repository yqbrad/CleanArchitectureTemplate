﻿namespace $safeprojectname$.Dtoes
{
    public interface IDto
    {
    }
}